from pymongo import MongoClient

from bson.objectid import ObjectId



class AnimalShelter(object):

    """ CRUD operations for Animal collection in MongoDB """



    def __init__(self):

        # Initializing the MongoClient. This helps to 

        # access the MongoDB databases and collections. 

        self.client = MongoClient('mongodb://%s:%s@localhost:YOUR_PORT_NUMBER' % (username, password))

        self.database = self.client['project']



# Complete this create method to implement the C in CRUD.

    def create(self, data):

        if data is not None:

            self.database.animals.insert(data)  # data should be dictionary
           
           if self.database.animals.find(data) is not -1:
           
               return true:
           
            else:
            
                return false:

        else:

            raise Exception("Nothing to save, because data parameter is empty")
        
        

# Create method to implement the R in CRUD. 

    def read(self, data):

        self.database.animals.find(data)
        if self.database.animals.find(data) is not -1:

            return true:

        else:

            return false:
