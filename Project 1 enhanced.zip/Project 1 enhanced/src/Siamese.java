
public class Siamese extends Cat {

    int weight; // additional class variables
    int age;


    // constructor
    public Siamese(String type, String breed, String name, int pounds, int years) {

        // invoke Cat class (super class) constructor
    	super(type, breed, name);
        weight = pounds;
        age = years;
    }

    // mutator methods
public void setWeight(int pounds) {
	weight = pounds;
}

// override toString() method to include additional cat information
@Override
public String toString() {
    return (super.toString() + "\nThe Siamese cat is " + age +
            " years old and weighs " + weight + " pounds.");
}

}
