
public class petClass {//pet traits
	private String petType;
	private String petName;
	private int petAge;
	private int dogSpace;
	private int catSpace;
	private int daysStay;
	private double amountDue;



	public petClass() {//constructor
	   petType = "pet";
	   petName = "name";
	   petAge = 0;
	   dogSpace = 0;
	   catSpace = 0;
	   daysStay = 0;
	   amountDue = 0.0;
	   
	}

	//mutators
	public void setPetType(String pet) {//ensures a pet type is either a cat or dog
	    if (pet == "dog" || pet == "cat")
	    {
	    petType = pet;
	    }
	}
	public String getPetType() {
	    return petType;
		
	}

	public void setPetName(String name) {
	    petName = name;
	}
	public String getPetName() {
	    return petName;
	}

	public void setPetAge(int age) {
	    petAge = age;
	}
	public int getPetAge() {
	    return petAge;
	}

	public void setDogSpace(int space) {
	    dogSpace = space;
	}
	public int getDogSpace() {
	    return dogSpace;
	}

	public void setCatSpace(int space) {
	    catSpace = space;
	}
	public int getCatSpace() {
	    return catSpace;
	}

	public void setDaysStay(int stay) {
		daysStay = stay;
	}
	public int getDaysStay() {
		return daysStay;
	}

	public void setAmountDue(double due) {
	    amountDue = due;
	}
	public double getAmountDue() {
	    return amountDue;
	}

	}

	


