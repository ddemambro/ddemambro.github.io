
public class Driver {

public static void main(String[] args) {
	Corgi dog = new Corgi("companion","corgi","Dozer",10,3);//create a Corgi
	dog.setTopTrick("high five");
	dog.toString();
	
	Siamese cat = new Siamese("indoor","siamese","Loki",2,1);//create a Siamese Cat
	cat.toString();
}

}
