
public class Cat extends petClass { //traits

    String type;
    String breed;
    String name;
    


public Cat (String type, String breed, String name) {    // constructor
	type = "type";
	breed = "breed";
	name = "name";
}

// method used to print cat information
public String toString() {
    String temp = "\nCAT DATA\n" + name + " is a " + breed +
            ", a " + type +  "cat.";
    return temp;
}


}

