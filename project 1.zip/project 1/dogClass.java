
public class dogClass {
	private String petType;
	private String petName;
	private int petAge;
	private int dogSpace;
	private int catSpace;
	private int daysStay;
	private double amountDue;
	public int dogSpaceNbr;
	public double dogWeight;
	public String grooming;
	


public void setPetType(String pet) {
    petType = pet;
}
public String getPetType() {
    return petType;
}

public void setPetName(String name) {
    petName = name;
}
public String getPetName() {
    return petName;
}

public void setPetAge(int age) {
    petAge = age;
}
public int getPetAge() {
    return petAge;
}

public void setDogSpace(int space) {
    dogSpace = space;
}
public int getDogSpace() {
    return dogSpace;
}

public void setCatSpace(int catSpace) {
    catSpace = catSpace;
}
public int getCatSpace() {
    return catSpace;
}

public void setDaysStay(int stay) {
	daysStay = stay;
}
public int getDaysStay() {
	return daysStay;
}

public void setAmountDue(double due) {
    amountDue = due;
}
public double getAmountDue() {
    return amountDue;
}

public void setDogSpaceNbr(int dogSpace) {
    dogSpaceNbr = dogSpace;
}
public int getDogSpaceNbr() {
    return dogSpaceNbr;
}

public void setDogWeight(double weight) {
    dogWeight = weight;
}
public double getDogWeight() {
    return dogWeight;
}

public void setGrooming(String groom) {
    grooming = groom;
}
public String getGrooming() {
    return grooming;
}
public void createPet() {
	
	dogClass newDog = new dogClass();
	setPetType(petType);
	setPetName(petName);
	setPetAge(petAge);
	
		
}
}
