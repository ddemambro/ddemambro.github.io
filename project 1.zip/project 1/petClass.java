
public class petClass {
	private String petType;
	private String petName;
	private int petAge;
	private int dogSpace;
	private int catSpace;
	private int daysStay;
	private double amountDue;



	public petClass() {
	   petType = "pet";
	   petName = "name";
	   petAge = 0;
	   dogSpace = 0;
	   catSpace = 0;
	   daysStay = 0;
	   amountDue = 0.0;
	   
	}

	public void setPetType(String pet) {
	    petType = pet;
	}
	public String getPetType() {
	    return petType;
	}

	public void setPetName(String name) {
	    petName = name;
	}
	public String getPetName() {
	    return petName;
	}

	public void setPetAge(int age) {
	    petAge = age;
	}
	public int getPetAge() {
	    return petAge;
	}

	public void setDogSpace(int space) {
	    dogSpace = space;
	}
	public int getDogSpace() {
	    return dogSpace;
	}

	public void setCatSpace(int catSpace) {
	    catSpace = catSpace;
	}
	public int getCatSpace() {
	    return catSpace;
	}

	public void setDaysStay(int stay) {
		daysStay = stay;
	}
	public int getDaysStay() {
		return daysStay;
	}

	public void setAmountDue(double due) {
	    amountDue = due;
	}
	public double getAmountDue() {
	    return amountDue;
	}

	}

	


