
public class Dog { //traits

    String type;
    String breed;
    String name;
    String topTrick;


public Dog () {    // constructor
	type = "type";
	breed = "breed";
	name = "name";
}
public void setTopTrick(String trick) {
	topTrick = trick;
}
	



    // methods


    // method used to print Dog information
    public String toString() {
        String temp = "\nDOG DATA\n" + name + " is a " + breed +
                ", a " + type + " dog. \nThe top trick is : " +
                topTrick + ".";
        return temp;
    }
    

}

