
public class Driver {

public static void main(String[] args) {
	Corgi dog = new Corgi("companion","corgi","dozer",10,3);
	dog.setTopTrick("high five");
	dog.toString();	
}

}
