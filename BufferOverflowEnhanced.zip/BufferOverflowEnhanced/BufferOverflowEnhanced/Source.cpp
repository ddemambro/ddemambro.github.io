// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>
#include <cstring>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  varaible, and its position in the declaration. It must always be directly before the variable used for input.

	const std::string account_number = "CharlieBrown42";
	std::string user_input;
	int user_input_length;//int intialized

	do {//do while loop to ensure loop iterates at least once
		std::cout << "Enter a value: ";//user inputs a value
		std::cin >> user_input;
		user_input_length = size(user_input);//int made to equal length of user_input
		
		

	} while (user_input_length > 20);//loop continues until user_input length is 20 charcters or less
	

	std::cout << "You entered: " << user_input << std::endl; //prints user input
	std::cout << "Account Number = " << account_number << std::endl;//prints account number
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
